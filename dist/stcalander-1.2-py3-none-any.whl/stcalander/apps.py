from django.apps import AppConfig

class myAppNameConfig(AppConfig):
    name = 'stcalander'
    verbose_name = 'stcalander'